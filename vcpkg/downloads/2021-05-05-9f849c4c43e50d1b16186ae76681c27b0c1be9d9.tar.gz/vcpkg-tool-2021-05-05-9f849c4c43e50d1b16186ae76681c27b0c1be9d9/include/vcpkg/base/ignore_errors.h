#pragma once

namespace vcpkg
{
    struct ignore_errors_t
    {
    };

    constexpr ignore_errors_t ignore_errors;
}
