#pragma once

#include <vcpkg/base/span.h>
