#pragma once

namespace vcpkg
{
    template<class T>
    struct Optional;
}
