#pragma once

namespace vcpkg::Util
{
    template<class T>
    struct LockGuardPtr;

    template<class T>
    struct LockGuarded;
}
