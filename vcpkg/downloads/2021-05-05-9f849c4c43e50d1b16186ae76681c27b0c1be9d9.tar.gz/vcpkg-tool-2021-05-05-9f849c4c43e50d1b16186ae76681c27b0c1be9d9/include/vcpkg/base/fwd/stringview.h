#pragma once

namespace vcpkg
{
    struct StringView;
}
