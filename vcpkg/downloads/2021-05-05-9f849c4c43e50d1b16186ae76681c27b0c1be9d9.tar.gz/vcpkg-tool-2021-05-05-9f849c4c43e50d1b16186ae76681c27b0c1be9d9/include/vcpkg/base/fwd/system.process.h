#pragma once

namespace vcpkg::System
{
    struct CMakeVariable;
    struct Command;
    struct CommandLess;
}
