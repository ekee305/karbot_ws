#pragma once

namespace vcpkg
{
    struct RegistryEntry;
    struct RegistryImplementation;
    struct Registry;
    struct RegistrySet;
    struct LockFile;
}
