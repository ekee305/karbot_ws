#pragma once

namespace vcpkg
{
    struct ToolsetArchOption;
    struct Toolset;
    struct VcpkgPaths;
}
