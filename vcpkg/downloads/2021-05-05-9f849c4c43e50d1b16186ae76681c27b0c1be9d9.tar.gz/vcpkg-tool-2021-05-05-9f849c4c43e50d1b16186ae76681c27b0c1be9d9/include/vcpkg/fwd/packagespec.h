#pragma once

namespace vcpkg
{
    struct PackageSpec;
}
