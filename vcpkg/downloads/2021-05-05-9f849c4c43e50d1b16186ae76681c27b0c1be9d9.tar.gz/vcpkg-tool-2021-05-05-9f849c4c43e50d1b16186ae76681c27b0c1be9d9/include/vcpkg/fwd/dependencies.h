#pragma once

namespace vcpkg::Dependencies
{
    struct InstallPlanAction;
    struct ActionPlan;
}
