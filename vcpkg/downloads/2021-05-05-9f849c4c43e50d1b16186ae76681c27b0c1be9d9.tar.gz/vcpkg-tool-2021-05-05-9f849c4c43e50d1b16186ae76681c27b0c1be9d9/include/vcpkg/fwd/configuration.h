#pragma once

namespace vcpkg
{
    struct Configuration;
}
