#pragma once

namespace vcpkg::PortFileProvider
{
    struct PortFileProvider;
    struct PathsPortFileProvider;
    struct IVersionedPortfileProvider;
    struct IBaselineProvider;
    struct IOverlayProvider;
}
