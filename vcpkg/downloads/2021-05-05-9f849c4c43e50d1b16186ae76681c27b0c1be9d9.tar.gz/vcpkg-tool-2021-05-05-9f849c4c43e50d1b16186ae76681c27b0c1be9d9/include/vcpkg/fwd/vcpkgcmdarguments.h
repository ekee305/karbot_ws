#pragma once

namespace vcpkg
{
    struct ParsedArguments;
    struct CommandSwitch;
    struct CommandSetting;
    struct CommandMultiSetting;
    struct CommandOptionsStructure;
    struct CommandStructure;
    struct HelpTableFormatter;
    struct VcpkgCmdArguments;
    struct FeatureFlagSettings;
}
