#pragma once

namespace vcpkg::Build
{
    struct BuildInfo;
    struct PreBuildInfo;
}
