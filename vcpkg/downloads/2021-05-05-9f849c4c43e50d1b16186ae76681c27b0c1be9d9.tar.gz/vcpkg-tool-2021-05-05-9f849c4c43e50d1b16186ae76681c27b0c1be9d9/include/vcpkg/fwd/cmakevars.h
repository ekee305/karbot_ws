#pragma once

namespace vcpkg::CMakeVars
{
    struct CMakeVarProvider;
}
